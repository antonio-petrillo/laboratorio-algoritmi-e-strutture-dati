#ifndef MENU_H
#define MENU_H

int LoginMenu(void);

int AdminMenu(void);

int UserMenu(void);

int UserMenu1(void);

int UserMenu2(void);

int UserMenuLogin(void);

void clearInputBuffer();

#endif /* Menu_h */


